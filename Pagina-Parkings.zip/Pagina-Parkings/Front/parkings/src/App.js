import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import InsertForm from './InsertForm';
import VistaAdmin from './VistaAdmin';
import Home from './Home';
import './App.css';

/*const NavBar = () => {
  return (
    <nav className="navbar">
      <ul>
        <li><Link to="/">Inicio</Link></li>
        <li><Link to="/VistaAdmin">Vista Admin</Link></li>
        <li><Link to="/InsertForm">Insertar Formulario</Link></li>
      </ul>
    </nav>
  );
};*/

const Footer = () => {
  return (
    <div className="footer">
      <p>&copy; 2023 Tu Página. Todos los derechos reservados.</p>
    </div>
  );
};

const App = () => {
  return (
    <BrowserRouter>
      <div className="center-content">
        <Routes>
          <Route index element={<Home />} />
          <Route path="/VistaAdmin" element={<VistaAdmin />} />
          <Route path="/InsertForm" element={<InsertForm />} />
          <Route path="*" element={<h1>404</h1>} />
        </Routes>
        <Footer />
      </div>
    </BrowserRouter>
  );
};

export default App;
