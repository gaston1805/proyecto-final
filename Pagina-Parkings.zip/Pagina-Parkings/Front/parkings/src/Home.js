import { Link } from "react-router-dom";

export default function Home() {
    return (
        <div className="Home">
            <h1>Parkings</h1>
            <p>toque el boton para subir su garage</p>
            <div className="buttonDiv" >
                <Link to="/InsertForm">
                    <button className="button">Ir</button>
                </Link>
            </div>
            <p>toque el boton para administrar su garage</p>
            <div className="buttonDiv" >
                <Link to="/VistaAdmin">
                    <button className="button">Ir</button>
                </Link>
            </div>

        </div>

    )
}