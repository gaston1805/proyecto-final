import React, { useState } from 'react';
//import { GoogleMap, LoadScript, Geocoder } from '@react-google-maps/api';
//import { Autocomplete } from '@react-google-maps/api';
import axios from 'axios';
import './InsertForm.css';

const InsertForm = () => {
  const [formValues, setFormValues] = useState({
    Nombre: '',
    Direccion: '',
    Capacidad: '',
    Horarios: '',
    Precios: '',
    Disponibilidad: ''
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormValues({ ...formValues, [name]: value });
  };

 /* const MapComponent = () => {
    const [address, setAddress] = useState('');
    const [latLng, setLatLng] = useState(null);
  
    const handleGeocode = (results) => {
      const { lat, lng } = results[0].geometry.location;
      setLatLng({ lat, lng });
    }*/

  const handleSubmit = async (e) => {
    e.preventDefault();
    axios
      .post('http://localhost:5000/garage/', formValues)
      .then((response) => {
        console.log('Garage created:', response.data);
        // Reset form values
        setFormValues({
          Nombre: '',
          Direccion: '',
          Capacidad: '',
          Horarios: '',
          Precios: '',
          Disponibilidad: ''
        });
      })
      .catch((error) => {
        console.error('Error creating garage:', error);
        // Handle error case
      });
  };

  return (
    <div className="insert-form">
      <div className="insert-form__header">
        <h2>Parkings</h2>
        <h2>Sube tu garage</h2>
      </div>
      <form className="insert-form__form" onSubmit={handleSubmit}>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="nombre">
            Nombre
          </label>
          <input
            type="text"
            id="nombre"
            name="Nombre"
            className="insert-form__input"
            value={formValues.Nombre}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="direccion">
            Dirección
          </label>
          <input
            type="text"
            id="direccion"
            name="Direccion"
            className="insert-form__input"
            value={formValues.Direccion}
            onChange={handleInputChange}
            required
          />          
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="capacidad">
            Capacidad
          </label>
          <input
            type="number"
            id="capacidad"
            name="Capacidad"
            className="insert-form__input"
            value={formValues.Capacidad}
            onChange={handleInputChange}
          />
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="horarios">
            Horarios
          </label>
          <input
            type="time"
            id="horarios"
            name="Horarios"
            className="insert-form__input"
            value={formValues.Horarios}
            onChange={handleInputChange}
            required
            max="24:00"
            min="00:00"
          />
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="precios">
            Precios
          </label>
          <input
            type="number"
            id="precios"
            name="Precios"
            className="insert-form__textarea"
            value={formValues.Precios}
            onChange={handleInputChange}
          />
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="disponibilidad">
            Disponibilidad
          </label>
          <input
            type="number"
            id="disponibilidad"
            name="Disponibilidad"
            className="insert-form__textarea"
            value={formValues.Disponibilidad}
            onChange={handleInputChange}
          />
        </div>
        <button type="submit" className="insert-form__button">
          Subir garage
        </button>
      </form>
    </div>
  );
}

export default InsertForm;