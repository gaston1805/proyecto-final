import { Redirect } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const CrearRegistro = () => {
    const [redirectHome, setRedirectHome] = useState(false);
    const [formValues, setFormValues] = useState({
      Patente: '',
      FechaEntrada: '',
      FechaSalida: '',
      HoraEntrada: '',
      HoraSalida: '',
      FkGarage: '',
    });
  const navigate = useNavigate();
  const [garages, setGarages] = useState([]);

  useEffect(() => {
    const fetchGarages = async () => {
      try {
        const response = await axios.get('http://localhost:5000/garage/');
        setGarages(response.data);
      } catch (error) {
        console.error('Error fetching garages:', error);
      }
    };

    fetchGarages();
  }, []);
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    axios
      .post('http://localhost:5000/ingresoegreso/', formValues)
      .then((response) => {
        console.log('Register uploaded:', response.data);
        // Reset form values
        setFormValues({
          Patente: '',
          FechaEntrada: '',
          FechaSalida: '',
          HoraEntrada: '',
          HoraSalida: '',
          FkGarage: '',
        });
      })
      .catch((error) => {
        console.error('Error creating register:', error);
        // Handle error case
      });
  };

  useEffect(() => {
    if (redirectHome) {
      navigate('/Home'); // Utiliza useNavigate para la redirección
    }
  }, [redirectHome, navigate]);
  return(
    <div className="crear-registro-form">
      <div className="insert-form__header">
        <h2>Parkings</h2>
        <h2>Sube un registro</h2>
      </div>
      <form className="insert-form__form" onSubmit={handleSubmit}>
      <div className="insert-form__row">
      <label className="insert-form__label" htmlFor="garage">
            Seleccionar Garage
          </label>
          <select
            id="garage"
            name="FkGarage"
            className="insert-form__input"
            value={formValues.Nombre}
            onChange={handleInputChange}
            required
          >
            <option value="" disabled>
              Selecciona un garage
            </option>
            {garages.map((garage) => (
              <option key={garage.Nombre} value={garage.Nombre}>
                {garage.Nombre}
              </option>
            ))}
          </select>
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="nombre">
            Patente
          </label>
          <input
            type="text"
            id="patente"
            name="Patente"
            className="insert-form__input"
            value={formValues.Patente}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="horarios">
            Hora de Entrada
          </label>
          <input
            type="time"
            id="horaentrada"
            name="HoraEntrada"
            className="insert-form__input"
            value={formValues.HoraEntrada}
            onChange={handleInputChange}
            required
            max="24:00"
            min="00:00"
          />
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="horarios">
            Hora de Salida
          </label>
          <input
            type="time"
            id="horasalida"
            name="HoraSalida"
            className="insert-form__input"
            value={formValues.HoraSalida}
            onChange={handleInputChange}
            required
            max="24:00"
            min="00:00"
          />
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="nombre">
            Fecha de Entrada
          </label>
          <input
            type="date"
            id="fechaEntrada"
            name="FechaEntrada"
            className="insert-form__input"
            value={formValues.FechaEntrada}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="nombre">
            Fecha de Entrada
          </label>
          <input
            type="date"
            id="fechaSalida"
            name="FechaSalida"
            className="insert-form__input"
            value={formValues.FechaSalida}
            onChange={handleInputChange}
            required
          />
        </div>
        <button type="submit" className="insert-form__button">
          Subir Registro
        </button>
        <button onClick={() => navigate('/Home')}> Inicio </button>
      </form>
    </div>
  );
}
export default CrearRegistro;


 
  