import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './InsertForm.css';
import { useNavigate } from 'react-router-dom';

const InsertForm = ({ initialValues, onCancelEdit, onSubmit }) => {
  const [formValues, setFormValues] = useState({
    Nombre: '',
    Direccion: '',
    Capacidad: '',
    Horarios: '',
    Precios: '',
    Disponibilidad: '',
    Latitud: null,
    Longitud: null,
  });
  const [coordenadas, setCoordenadas] = useState(null);
  const navigate = useNavigate();

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const handleGeocode = async () => {
    try {
      const response = await axios.get(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
          formValues.Direccion
        )}`
      );

      if (response.data.length > 0) {
        const { lat, lon } = response.data[0];
        setFormValues({ ...formValues, Latitud: lat, Longitud: lon });
        setCoordenadas({ latitud: lat, longitud: lon });
      }
    } catch (error) {
      console.error('Error geocoding address:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await handleGeocode();

    // No es necesario realizar la llamada axios aquí
    // Deja que el componente padre maneje la lógica del envío

    // Limpia los valores después del envío (esto puede depender de tu lógica específica)
    
    axios
      .post('http://localhost:5000/garage/', formValues)
      .then((response) => {
        console.log('Garage created:', response.data);
        // Reset form values
        setFormValues({
          Nombre: '',
          Direccion: '',
          Capacidad: '',
          Horarios: '',
          Precios: '',
          Disponibilidad: '',
          Latitud: null,
          Longitud: null
        });
        setCoordenadas(null);
      })
      .catch((error) => {
        console.error('Error creating garage:', error);
        // Handle error case
      });
    };

  return (
    <div className="insert-form">
      <div className="insert-form__header">
        <h2>Parkings</h2>
        <h2>Sube tu garage</h2>
      </div>
      <form className="insert-form__form" onSubmit={handleSubmit}>
      <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="nombre">
            Nombre
          </label>
          <input
            type="text"
            id="nombre"
            name="Nombre"
            className="insert-form__input"
            value={formValues.Nombre}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="direccion">
            Dirección
          </label>
          <input
            type="text"
            id="direccion"
            name="Direccion"
            className="insert-form__input"
            value={formValues.Direccion}
            onChange={handleInputChange}
            required
          />
        </div>
        
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="capacidad">
            Capacidad
          </label>
          <input
            type="number"
            id="capacidad"
            name="Capacidad"
            className="insert-form__input"
            value={formValues.Capacidad}
            onChange={handleInputChange}
          />
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="horarios">
            Horarios
          </label>
          <input
            type="time"
            id="horarios"
            name="Horarios"
            className="insert-form__input"
            value={formValues.Horarios}
            onChange={handleInputChange}
            required
            max="24:00"
            min="00:00"
          />
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="precios">
            Precios
          </label>
          <input
            type="number"
            id="precios"
            name="Precios"
            className="insert-form__textarea"
            value={formValues.Precios}
            onChange={handleInputChange}
          />
        </div>
        <div className="insert-form__row">
          <label className="insert-form__label" htmlFor="disponibilidad">
            Disponibilidad
          </label>
          <input
            type="number"
            id="disponibilidad"
            name="Disponibilidad"
            className="insert-form__textarea"
            value={formValues.Disponibilidad}
            onChange={handleInputChange}
          />
        </div>
        <div className="insert-form__row">
          <button
            type="button"
            onClick={handleGeocode}
            className="insert-form__button"
          >
            Obtener Coordenadas
          </button>
        </div>
        {coordenadas && (
          <div className="insert-form__coordinates">
            <p>Latitud: {coordenadas.latitud}</p>
            <p>Longitud: {coordenadas.longitud}</p>
          </div>
        )}
        <button type="submit" className="insert-form__button">
          Subir garage
        </button>
        <button onClick={() => navigate('/Home')}> Inicio </button>
      </form>
    </div>
  );
}

export default InsertForm;