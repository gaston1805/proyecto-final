// VistaAdmin.jsx
import React, { useState, useEffect } from 'react';
import InsertForm from './InsertForm';
import CrearRegistro from './Registrar';
import axios from 'axios';
import './Administrador.css';
import { Redirect } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';


const VistaAdmin = () => {
  const [editMode, setEditMode] = useState(false);
  const [editMode2, setEditMode2] = useState(false);
  const [garageData, setGarageData] = useState({});
  const [garages, setGarages] = useState([]);
  const [IngresosEgresos, setIngresosEgresos] = useState([]);
  const [registrosData, setRegistrosData] = useState({});
  const [Cliente, setCliente] = useState([]);
  const [redirectHome, setRedirectHome] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    const fetchGarages = async () => {
      try {
        const response = await axios.get('http://localhost:5000/garage/');
        setGarages(response.data);
      } catch (error) {
        console.error('Error fetching garages:', error);
      }
    };

    const fetchIngresos = async () => {
      try {
        const response = await axios.get('http://localhost:5000/ingresoegreso/');
        setIngresosEgresos(response.data);
      } catch (error) {
        console.error('Error fetching ingresos/egresos:', error);
      }
    };

    const fetchCliente = async () => {
      try {
        const response = await axios.get('http://localhost:5000/cliente/');
        setCliente(response.data);
      } catch (error) {
        console.error('Error fetching ingresos/egresos:', error);
      }
    };

    fetchGarages();
    fetchIngresos();
    fetchCliente();
  }, []);

  const handleEdit = (garage) => {
    setEditMode(true);
    setGarageData(garage);
  };

  const handleEdit2 = (registros) => {
    setEditMode2(true);
    setRegistrosData(registros);
  }
  

  const handleCancelEdit = () => {
    setEditMode(false);
    setGarageData({});
  };

  const handleSubmit = async (updatedGarageData) => {
    try {
      if (editMode) {
        await axios.post('http://localhost:5000/garage/', updatedGarageData);
      }

      const response = await axios.get('http://localhost:5000/garage/');
      setGarages(response.data);

      setEditMode(false);
      setGarageData({});
      setRedirectHome(true);
    } catch (error) {
      console.error('Error submitting form:', error);
    }
  };

  const handleSubmit2 = async (updatedRegistroData) => {
    try {
      if (editMode2) {
        await axios.post('http://localhost:5000/ingresoegreso/', updatedRegistroData);
      }

      const response = await axios.get('http://localhost:5000/ingresoegreso/');
      setIngresosEgresos(response.data);

      setEditMode2(false);
      setRegistrosData({});
      setRedirectHome(true);
    } catch (error) {
      console.error('Error submitting form:', error);
    }
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('es-ES', options);
  };

  const formatTime = (timeString) => {
    return new Date(timeString).toLocaleTimeString('es-ES');
  };

  useEffect(() => {
    if (redirectHome) {
      navigate('/Home');
    }
  }, [redirectHome, navigate]);
  return (
    <div className="container">
      <div className="left-section">
        <h1>Administrador</h1>
        {editMode ? (
          <div>
            <h2>Editar Garage</h2>
            <InsertForm
              data={garageData}
              onCancelEdit={handleCancelEdit}
              onSubmit={handleSubmit}
            />
          </div>
        ) : (
          <div>
            <h2>Garage para Editar</h2>
            {garages.length > 0 ? (
              <div>
                <ul>
                  <li>{garages[garages.length - 1].Nombre} </li>
                  <li>{garages[garages.length - 1].Direccion}</li> 
                  <li>{garages[garages.length - 1].Capacidad}</li> 
                  <li>{garages[garages.length - 1].Horarios}</li>
                  <li>{garages[garages.length - 1].Precios}</li> 
                  <li>{garages[garages.length - 1].Disponibilidad}</li>
                </ul>
                <button onClick={() => handleEdit(garages[garages.length - 1])}>
                  Editar
                </button>
              </div>
            ) : (
              <p>No hay garages para editar</p>
            )}
          </div>
        )}
        <button onClick={() => navigate('/Home')}>Inicio</button>
      </div>
  
      <div className="middle-section">
        {editMode2 ? (
            <div>
              <h2>agregar registro</h2>
            <CrearRegistro
              data={registrosData}
              onCancelEdit={handleCancelEdit}
              onSubmit={handleSubmit2}
              />
            </div>
        ) : (
          <div>
            <h2>Registros de Ingreso/Egreso</h2>
        {IngresosEgresos.length > 0 ? (
          <ul>
              <li>Patente: {IngresosEgresos[IngresosEgresos.length - 1].Patente}</li>
              <li>Hora de Entrada: {(IngresosEgresos[IngresosEgresos.length - 1].HoraEntrada)}</li>
              <li>Hora de Salida: {(IngresosEgresos[IngresosEgresos.length - 1].HoraSalida)}</li>
              <li>Fecha de Entrada: {formatDate(IngresosEgresos[IngresosEgresos.length - 1].FechaEntrada)}</li>
              <li>Fecha de salida: {formatDate(IngresosEgresos[IngresosEgresos.length - 1].FechaSalida)}</li>
          </ul>
        ) : (
          <p>No hay registros de ingreso/egreso</p>
        )}
        <button onClick={() => handleEdit2(IngresosEgresos[IngresosEgresos.length - 1])}>Registrar ingreso y egreso</button>
      </div>
        )}
        



      <div className='right-section'>
        <h2>Informacion del Cliente</h2>
        {Cliente.length > 0 ? ( 
          <ul>
            <li>Nombre: {Cliente[Cliente.length - 1].Nombre}</li>
            <li>Apellido: {Cliente[Cliente.length - 1].Apellido}</li>
            <li>Email: {Cliente[Cliente.length - 1].Email}</li>
            <li>Contraseña: {Cliente[Cliente.length - 1].Contraseña}</li>
            <li>Dni: {Cliente[Cliente.length - 1].Dni}</li>
            <li>Telefono: {Cliente[Cliente.length - 1].Telefono}</li>
          </ul>
            ) : (
            <p>No hay informacion del cliente</p>
        )}
      </div>
    </div>
    </div>
  );
};

export default VistaAdmin;
