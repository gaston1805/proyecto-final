import express from "express"
import clienteService from "./services/clienteService.js";
import Cliente from './models/cliente.js';
import GarageService from "./services/garageService.js";
import Garage from "./models/garage.js";
import ingresoegreso from "./models/ingresoEgreso.js";
import IngresosEgresos from "./services/ingresosEgresos.js";
import cors from "cors"


const app = express();
const port = 5000;
app.use(express.json())
app.use(cors());
const ClienteService = new clienteService();
const GaragService = new GarageService();
const ingresoegre = new IngresosEgresos();

app.get('/garage', async (req,res) => {
    const garages = await GaragService.GetGarages();
    return res.status(200).json(garages);
})

app.get('/cliente', async (req,res) => {
    const clientes = await ClienteService.GetClientes();
    return res.status(200).json(clientes);
})

app.get('/ingresoegreso', async (req,res) => {
    const ingresos = await ingresoegre.GetIngresosEgresos();
    return res.status(200).json(ingresos);
})

app.get('/cliente/:Id', async (req,res) => {
    console.log("estoy en getbyid");
    const clientes = await ClienteService.GetClientebyId(req.params.Id);
    return res.status(200).json(clientes);
})

app.get('/garage/:Id', async (req,res) => {
    const garage = await GaragService.GetGaragebyId(req.params.Id);
    return res.status(200).json(garage);
})

app.get('/ingresoEgreso/:Id', async (req,res) => {
    const ingreso = await ingresoegre.GetIngresosById(req.params.Id);
    return res.status(200).json(ingreso);
})

app.post('/garage/', async (req, res)=> {
    const garage = new Garage()
    garage.Nombre = req.body.Nombre
    garage.Direccion = req.body.Direccion
    garage.Capacidad = req.body.Capacidad
    garage.Horarios = req.body.Horarios
    garage.Precios = req.body.Precios
    garage.Disponibilidad = req.body.Disponibilidad
    await GaragService.Insert(garage)
    res.status(201).json(garage)
})

app.post('/cliente/', async (req, res)=> {
    const cliente = new Cliente()
    cliente.Nombre = req.body.Nombre
    cliente.Apellido = req.body.Apellido
    cliente.Email = req.body.Email
    cliente.Contraseña = req.body.Contraseña
    cliente.Dni = req.body.Dni
    cliente.Telefono = req.body.Telefono
    await ClienteService.Insert(cliente)
    res.status(201).json(cliente)
})

app.post('/ingresoegreso/', async (req, res)=> {
    const ingreso = new ingresoegreso()
    ingreso.FkGarage = req.body.FkGarage
    ingreso.Patente = req.body.Patente
    ingreso.FechaEntrada = req.body.FechaEntrada
    ingreso.FechaSalida = req.body.FechaSalida
    ingreso.HoraEntrada = req.body.HoraEntrada
    ingreso.HoraSalida = req.body.HoraSalida
    await ingresoegre.Insert(ingreso)
    res.status(201).json(ingreso)
})

app.put('/garage/:Id', async (req, res) => {
    console.log('estoy en put')
    const garage = await GaragService.Update(req.body, req.params.Id);
    console.log(garage);

    return res.status(200).json(garage);
  });

  app.put('/cliente/:Id', async (req, res) => {
    console.log('estoy en put')
    const cliente = await ClienteService.Update(req.body, req.params.Id);
    console.log(cliente);

    return res.status(200).json(cliente);
  });

  app.put('/ingresoegreso/:Id', async (req, res) => {
    console.log('estoy en put')
    const ingreso = await ingresoegre.Update(req.body, req.params.Id);
    console.log(ingreso);

    return res.status(200).json(ingreso);
  });

  app.delete('/garage/:Id', async(req, res) => {

    const id = req.params.Id;
    console.log('estoy en delete')
    const garage = await GaragService.deleteById(id)
    return res.status(201).json(garage);
    })

    app.delete('/cliente/:Id', async(req, res) => {

        const id = req.params.Id;
        console.log('estoy en delete')
        const cliente = await ClienteService.deleteById(id)
        return res.status(201).json(cliente);
    })
    app.delete('/ingresoegreso/:Id', async(req, res) => {

        const id = req.params.Id;
        console.log('estoy en delete')
        const ingreso = await ingresoegre.deleteById(id)
        return res.status(201).json(ingreso);
    })

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})