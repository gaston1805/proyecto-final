export default class Cliente {
    Id;
    Nombre;
    Apellido;
    Email;
    Contraseña;
    Dni;
    Telefono;
  }