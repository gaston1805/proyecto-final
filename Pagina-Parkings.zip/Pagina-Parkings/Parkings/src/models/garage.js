export default class Garage {
  Id;
  Nombre;
  Direccion;
  Capacidad;
  Horarios;
  Precios;
  Disponibilidad;
}