export default class ingresoegreso {
    Id;
    FkGarage;
    Patente;
    FechaEntrada;
    FechaSalida;
    HoraEntrada;
    HoraSalida;
}
