import sql from 'mssql';
import config from '../models/db.js';

export default class ClienteService{
    
    GetClientes = async () => { 

        let returnEntity = null;

        try{
            let pool = await sql.connect(config);
            let result = await pool.request()                   
            .query('SELECT * FROM Cliente');
            returnEntity = result.recordset;
        }   

        catch (error)

        {
            console.log(error)
        }
        return returnEntity;
    }

    GetClientebyId = async (Id) => {
        let returnEntity = null;

        try{
            let pool = await sql.connect(config);
            let result = await pool.request()
            .input('pId', sql.Int, Id)                   
            .query('SELECT Cliente.IdCliente, Cliente.Nombre as Nombre_Cliente, Cliente.Apellido, Cliente.Email, Cliente.Contraseña, Cliente.Dni, Cliente.Telefono, Garage.Nombre FROM Cliente INNER JOIN Garage ON Cliente.IdCliente = Garage.FkCliente WHERE IdCliente = @pId');
            returnEntity = result.recordset;
        }   

        catch (error)

        {
            console.log(error)
        }
        return returnEntity;
    }

    
    Insert = async (cliente) =>
    {

    const pool = await sql.connect(config);
    const response = await pool.request()
        
    .input('Nombre',sql.VarChar, cliente?.Nombre)
    .input('Apellido',sql.VarChar, cliente?.Apellido)
    .input('Email',sql.VarChar, cliente?.Email)
    .input('Contraseña',sql.VarChar, cliente?.Contraseña)
    .input('Dni',sql.Int, cliente?.Dni)
    .input('Telefono',sql.Int, cliente?.Telefono)
    
    .query(`INSERT INTO Cliente (Nombre, Apellido, Email, Contraseña, Dni, Telefono) VALUES (@Nombre, @Apellido, @Email, @Contraseña, @Dni, @Telefono)`);
    console.log(response)

    return response.recordset;
    }

    Update = async (cliente, Id) => {
        console.log(cliente);
    
            const pool = await sql.connect(config);
            const result = await pool.request()
            .input('pId', sql.Int, Id)
            .input('pNombre',sql.VarChar, cliente?.Nombre)
            .input('pApellido',sql.VarChar, cliente?.Apellido)
            .input('pEmail',sql.VarChar, cliente?.Email)
            .input('pContraseña',sql.VarChar, cliente?.Contraseña)
            .input('pDni',sql.Int, cliente?.Dni)
            .input('pTelefono',sql.Int, cliente?.Telefono)
    
    
            .query('UPDATE cliente SET Nombre = @pNombre, Apellido = @pApellido, Email = @pEmail, Contraseña = @pContraseña, Dni = @pDni, Telefono = @pTelefono  WHERE IdCliente = @pId');
            console.log(result)
    
            return result.recordset;
        }

    deleteById = async (Id) => {
        const pool = await sql.connect(config);
        const results = await pool.request().input("pId", Id).query('DELETE FROM Cliente WHERE @pId = IdCliente');
        
        return results.recordset;
    }

}