import sql from 'mssql';
import config from '../models/db.js';

export default class GarageService{

    GetGarages = async () => { 

        let returnEntity = null;

        try{
            let pool = await sql.connect(config);
            let result = await pool.request()             
            .query('SELECT * FROM Garage');
            returnEntity = result.recordset;
        }   

        catch (error)

        {
            console.log(error)
        }
        return returnEntity;
    }

    GetGaragebyId = async (Id) => {
        let returnEntity = null;

        try{
            let pool = await sql.connect(config);
            let result = await pool.request()
            .input('pId', sql.Int, Id)                   
            .query('SELECT Garage.idgarage, Garage.nombre as Nombre_Garage, garage.direccion, garage.capacidad, garage.horarios, garage.precios, garage.disponibilidad, Cliente.Nombre FROM Garage INNER JOIN Cliente ON Garage.FkCliente = Cliente.IdCliente WHERE IdGarage = @pId');
            returnEntity = result.recordset;
        }   

        catch (error)

        {
            console.log(error)
        }
        return returnEntity;
    }

    deleteById = async (Id) => {
        const pool = await sql.connect(config);
        const results = await pool.request().input("pId", Id).query('DELETE FROM Garage WHERE @pId = IdGarage');
    
        return results.recordset;
    }
    
    
     Update = async (garage, Id) => {
        console.log(garage);
    
            const pool = await sql.connect(config);
            const result = await pool.request()
            .input('pId', sql.Int, Id)
            .input('pNombre',sql.VarChar, garage?.Nombre)
            .input('pDireccion',sql.VarChar, garage?.Direccion)
            .input('pCapacidad',sql.Int, garage?.Capacidad)
            .input('pHorarios',sql.VarChar, garage?.Horarios)
            .input('pPrecios',sql.Int, garage?.Precios)
            .input('pDisponibilidad',sql.Int, garage?.Disponibilidad)
    
    
            .query('UPDATE Garage SET Nombre = @pNombre, Direccion = @pDireccion, Capacidad = @pCapacidad, Horarios = @pHorarios, Precios = @pPrecios, Disponibilidad = @pDisponibilidad  WHERE IdGarage = @pId');
            console.log(result)
    
            return result.recordset;
        }
     
     Insert = async (garage) =>
            {
    
            const pool = await sql.connect(config);
            const response = await pool.request()
                
            .input('Nombre',sql.VarChar, garage?.Nombre)
            .input('Direccion',sql.VarChar, garage?.Direccion)
            .input('Capacidad',sql.Int, garage?.Capacidad)
            .input('Horarios',sql.VarChar, garage?.Horarios)
            .input('Precios',sql.Int, garage?.Precios)
            .input('Disponibilidad',sql.Int, garage?.Disponibilidad)
            
            .query(`INSERT INTO Garage (Nombre, Direccion, Capacidad, Horarios, Precios, Disponibilidad) VALUES (@Nombre, @Direccion, @Capacidad, @Horarios, @Precios, @Disponibilidad)`);
            console.log(response)
    
            return response.recordset;
        }
}

