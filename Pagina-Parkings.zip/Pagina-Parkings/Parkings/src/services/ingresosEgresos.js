import sql from 'mssql';
import config from '../models/db.js';

export default class IngresosEgresos{

    GetIngresosEgresos = async () => { 

        let returnEntity = null;

        try{
            let pool = await sql.connect(config);
            let result = await pool.request()                   
            .query('SELECT * FROM ingresoEgresos');
            returnEntity = result.recordset;
        }   

        catch (error)

        {
            console.log(error)
        }
        return returnEntity;
    }

    Insert  = async (ingreso) =>
    {

    const pool = await sql.connect(config);
    const response = await pool.request()
        
    .input('Patente',sql.VarChar, ingreso?.Patente)
    .input('FechaEntrada',sql.VarChar, ingreso?.FechaEntrada)
    .input('FechaSalida',sql.VarChar, ingreso?.FechaSalida)
    .input('HoraEntrada',sql.VarChar, ingreso?.HoraEntrada)
    .input('HoraSalida',sql.VarChar, ingreso?.HoraSalida)

    
    .query(`INSERT INTO ingresoEgresos (Patente, FechaEntrada, FechaSalida, HoraEntrada, HoraSalida) VALUES (@Patente, @FechaEntrada, @FechaSalida, @HoraEntrada, @HoraSalida)`);
    console.log(response)

    return response.recordset;
    }
    Update = async (ingresoegres, Id) => {
        console.log(ingresoegres);

        const pool = await sql.connect(config);
        const result = await pool.request()
        .input('pId', sql.Int, Id)
        .input('pFkGarage', sql.Int, ingresoegres?.FkGarage)
        .input('pPatente',sql.VarChar, ingresoegres?.Patente)
        .input('pFechaEntrada',sql.Date, ingresoegres?.FechaEntrada)
        .input('pFechaSalida',sql.Date, ingresoegres?.FechaSalida)
        .input('pHoraEntrada',sql.Time, ingresoegres?.HoraEntrada)
        .input('pHoraSalida',sql.Time, ingresoegres?.HoraSalida)


        .query('UPDATE ingresoEgresos SET FkGarage = @pFkGarage, Patente = @pPatente, FechaEntrada = @pFechaEntrada, FechaSalida = @pFechaSalida, HoraEntrada = @pHoraEntrada, HoraSalida = @pHoraSalida WHERE Id = @pId');
        console.log(result)

        return result.recordset;
    }

    deleteById = async (Id) => {
        const pool = await sql.connect(config);
        const results = await pool.request().input("pId", Id).query('DELETE FROM ingresoEgresos WHERE @pId = Id');
    
        return results.recordset;
    }

    GetIngresosById = async (Id) => {
        let returnEntity = null;

        try{
            let pool = await sql.connect(config);
            let result = await pool.request()
            .input('pId', sql.Int, Id)                   
            .query('SELECT ingresoEgresos.*, Garage.Nombre FROM ingresoEgresos INNER JOIN Garage ON ingresoEgresos.FkGarage = Garage.IdGarage WHERE Id = @pId');
            returnEntity = result.recordset;
        }   

        catch (error)

        {
            console.log(error)
        }
        return returnEntity;
    }

}